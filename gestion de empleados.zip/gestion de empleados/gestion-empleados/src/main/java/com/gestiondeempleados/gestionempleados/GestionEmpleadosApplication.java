package com.gestiondeempleados.gestionempleados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionEmpleadosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionEmpleadosApplication.class, args);
	}

}

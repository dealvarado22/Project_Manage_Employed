package com.gestiondeempleados.gestionempleados;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "empelados")

public class resgistroempleado {
  
    @Id



    private Long id;
    private String nombre;
    private String apellido;
    private int telefono;
    private String correo;
    private String sexo;
    private double salario;

}
